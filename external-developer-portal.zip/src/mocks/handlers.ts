import { delay, http, HttpResponse } from 'msw'
import posts from '~/mocks/data/posts.json'

export const handlers = [
  http.get('/posts', async () => {
    await delay('real')
    return HttpResponse.json(posts)
  }),
]
