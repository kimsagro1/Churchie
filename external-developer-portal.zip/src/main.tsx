import React from 'react'
import reactDom from 'react-dom/client'
import { AgDesignProvider } from '~/lib/ag-design-system/ag-design-system-provider'
import { TanStackQueryProvider } from '~/lib/tan-stack-query/tan-stack-query-provider'
import { TanStackRouterProvider } from '~/lib/tan-stack-router/tan-stack-router-provider'

async function enableMocking() {
  if (process.env.NODE_ENV !== 'development') return

  const { worker } = await import('~/mocks/browser')
  return worker.start()
}

enableMocking().then(() => {
  // biome-ignore lint/style/noNonNullAssertion: reason dom node will always be there
  reactDom.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <AgDesignProvider>
        <TanStackQueryProvider>
          <TanStackRouterProvider />
        </TanStackQueryProvider>
      </AgDesignProvider>
    </React.StrictMode>,
  )
})
