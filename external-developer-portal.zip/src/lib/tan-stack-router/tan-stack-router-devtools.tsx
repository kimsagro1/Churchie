import React from 'react'
import { Suspense } from 'react'

const LazyLoadedDevtools =
  process.env.NODE_ENV === 'production'
    ? () => null // Render nothing in production
    : React.lazy(() =>
        // Lazy load in development
        import('@tanstack/router-devtools').then((res) => ({
          default: res.TanStackRouterDevtools,
        })),
      )

export function TanStackRouterDevtools({
  buttonPosition,
}: { buttonPosition: 'bottom-right' | 'top-left' | 'top-right' | 'bottom-left' }) {
  return (
    <Suspense>
      <LazyLoadedDevtools position={buttonPosition} />
    </Suspense>
  )
}
