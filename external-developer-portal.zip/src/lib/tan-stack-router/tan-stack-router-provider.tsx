import { type QueryClient, useQueryClient } from '@tanstack/react-query'
import { RouterProvider, createRouter } from '@tanstack/react-router'
import { useState } from 'react'
import { routeTree } from '~/routeTree.gen'

function getRouter(queryClient: QueryClient) {
  const router = createRouter({
    routeTree,
    context: {
      queryClient,
    },
    defaultPreload: 'intent',
    // Since we're using React Query, we don't want loader calls to ever be stale
    // This will ensure that the loader is always called when the route is preloaded or visited
    defaultPreloadStaleTime: 0,

    defaultPendingMs: 5000,
  })

  return router
}

declare module '@tanstack/react-router' {
  interface Register {
    router: ReturnType<typeof getRouter>
  }
}

export function TanStackRouterProvider() {
  const queryClient = useQueryClient()
  const [router] = useState(() => getRouter(queryClient))

  return <RouterProvider router={router}  />
}
