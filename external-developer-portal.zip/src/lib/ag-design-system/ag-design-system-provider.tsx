import { theme } from '@ag.ds-next/react/ag-branding'
import { Core, type LinkProps } from '@ag.ds-next/react/core'
import { Link } from '@tanstack/react-router'
import { type PropsWithChildren, forwardRef } from 'react'

export function AgDesignProvider({ children }: PropsWithChildren) {
  return (
    <Core theme={theme} linkComponent={TanstackRouterLinkComponent}>
      {children}
    </Core>
  )
}

const TanstackRouterLinkComponent = forwardRef<HTMLAnchorElement, LinkProps>(function LinkComponent(
  { href, ...props },
  ref,
) {
  if (!href) return <a ref={ref} {...props} />

  // Use an `a` tag when linking externally
  // Regex finds links starting with: `http://` | `https://` | `//`
  if (href && /^(https?:\/\/|\/\/)/i.test(href)) {
    return <a ref={ref} href={href} {...props} />
  }

  return <Link ref={ref} to={href} {...props} />
})
