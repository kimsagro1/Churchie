import { Logo } from '@ag.ds-next/react/ag-branding'
import { Box } from '@ag.ds-next/react/box'
import { tokens } from '@ag.ds-next/react/core'
import { Flex } from '@ag.ds-next/react/flex'
import { Footer, FooterDivider } from '@ag.ds-next/react/footer'
import { Header } from '@ag.ds-next/react/header'
import { LinkList } from '@ag.ds-next/react/link-list'
import { MainNav } from '@ag.ds-next/react/main-nav'
import { SkipLinks } from '@ag.ds-next/react/skip-link'
import { Stack } from '@ag.ds-next/react/stack'
import { Text } from '@ag.ds-next/react/text'
import type { QueryClient } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { Link, Outlet, createRootRouteWithContext } from '@tanstack/react-router'
import { useMemo } from 'react'
import { TanStackRouterDevtools } from '~/lib/tan-stack-router/tan-stack-router-devtools'

const NAV_ITEMS = {
  primary: [
    { label: 'Home', href: '/' },
    { label: 'About', href: '/about' },
  ],
}

const footerLinks = [{ label: 'About', href: '/about' }]

export const Route = createRootRouteWithContext<{
  queryClient: QueryClient
}>()({
  component: RootComponent,
})

function RootComponent() {
  const year = useMemo(() => new Date().getFullYear(), [])

  return (
    <>
      <SkipLinks
        links={[
          { href: '#main-content', label: 'Skip to main content' },
          { href: '#main-nav', label: 'Skip to main navigation' },
        ]}
      />
      <Flex flexDirection='column' fontFamily='body' minHeight='100vh'>
        <Stack palette='dark'>
          <Header
            background='bodyAlt'
            logo={<Logo />}
            heading='Agriculture Design System'
            subline='Design System for the Export Service'
            badgeLabel='Beta'
          />
          <MainNav id='main-nav' items={NAV_ITEMS.primary} />
        </Stack>
        <Box flexGrow={1}>
          <Link to='/about' />
          <Outlet />
        </Box>
        <Box palette='dark'>
          <Footer background='bodyAlt'>
            <nav aria-label='footer'>
              <LinkList links={footerLinks} horizontal />
            </nav>
            <FooterDivider />
            <Text fontSize='xs' maxWidth={tokens.maxWidth.bodyText}>
              We acknowledge the traditional owners of country throughout Australia and recognise their continuing
              connection to land, waters and culture. We pay our respects to their Elders past, present and emerging.
            </Text>
            <Text fontSize='xs' maxWidth={tokens.maxWidth.bodyText}>
              &copy; {year} Department of Agriculture, Fisheries and Forestry
            </Text>
          </Footer>
        </Box>
      </Flex>
      <ReactQueryDevtools buttonPosition='top-right' />
      <TanStackRouterDevtools buttonPosition='bottom-right' />
    </>
  )
}
