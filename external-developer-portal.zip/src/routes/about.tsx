import { queryOptions, useSuspenseQuery } from '@tanstack/react-query'
import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/about')({
  component: About,
  loader: (options) => {
    options.context.queryClient.ensureQueryData(postsQueryOptions())
  },
  pendingComponent: () => "Loading..."
})

function About() {
  const postsQuery = useSuspenseQuery(postsQueryOptions())
  const posts = postsQuery.data

  return (
    <div>
      <ul>
        {posts.map((p) => (
          <li key={p.id}>{p.title}</li>
        ))}
      </ul>
    </div>
  )
}

export const postsQueryOptions = () =>
  queryOptions({
    queryKey: ['posts'],
    queryFn: ({ signal }) =>
      fetch('/posts', {
        signal,
      }).then((response) => {
        if (!response.ok) {
          throw new Error(response.statusText)
        }
        return response.json() as Promise<Posts>
      }),
  })

type Posts = Post[]

type Post = {
  userId: number
  id: number
  title: string
  completed: boolean
}
